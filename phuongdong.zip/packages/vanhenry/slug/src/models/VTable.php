<?php

namespace vanhenry\slug\models;

use Illuminate\Database\Eloquent\Model;
use Watson\Rememberable\Rememberable;

class VTable extends Model 
{
	use Rememberable;
    
}
