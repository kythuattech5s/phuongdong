<?php

namespace vanhenry\slug\models;

use Illuminate\Database\Eloquent\Model;
use Watson\Rememberable\Rememberable;

class VDetailTable extends Model 
{
	use Rememberable;
    
}
