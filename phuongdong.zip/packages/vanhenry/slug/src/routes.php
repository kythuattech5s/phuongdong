<?php 
// Route::get('/{lv1}', 'vanhenry\slug\HController@slugOneLevel');
// Route::get('/{lv1}/{lv2}', 'vanhenry\slug\HController@slugTwoLevel');


 ?>