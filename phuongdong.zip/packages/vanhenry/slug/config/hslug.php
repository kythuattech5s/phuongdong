<?php 

return array(
	/*Slug dựa trên trường...*/
	"build_from" =>"name",
	/*Lưu vào trường...*/
	"save_to" =>"slug",
	/*Phân cách các ký tự*/
	"separator" =>"-",
	/*Định dạng đuôi của đường link*/
	"extension"=>"",
	/*Có thực hiện cập nhật mới lúc update không?*/
	"on_update"=>false,
	/*Tự động tạo slug bằng javascript*/ 
	"autogen"=>true

);

 ?>