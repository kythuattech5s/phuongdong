<!DOCTYPE html>
<html>
<head>
	<title>Thông báo</title>
</head>
<body>
	<div class="box-fire">
		<h3>Cảnh báo truy cập</h3>
		<p>{!!$err!!}</p>
	</div>
	<style type="text/css">
		.box-fire{
			border: 1px solid #ff6464;
   			 padding: 0px;
		}
		.box-fire h3{
		    text-transform: uppercase;
		    color: #ffffff;
		    margin: 0;
		    background: #ff9900;
		    padding: 5px;
		}
	</style>
</body>
</html>