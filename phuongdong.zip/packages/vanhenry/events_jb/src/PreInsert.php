<?php namespace vanhenry\events_jb;
use App\ExamQuestion;
use App\Question;
class PreInsert{
    public function handle($table,$data){
    	
    }
}