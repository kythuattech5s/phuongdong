<?php namespace vanhenry\events_jb;

use App\ExamQuestion;

class HeaderView{

    public function handle(){
    	return ["vh::more.havi.num_orders"];

    }

}