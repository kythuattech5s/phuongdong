<?php namespace vanhenry\events_jb;
use App\ExamQuestion;
class GenerateView{
    public function handle($table){

    	$tblmap = $table->get("table_map","");
        
    }
}