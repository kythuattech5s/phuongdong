<?php 
return [
    'hello' => 'Xin chào'
];

?>