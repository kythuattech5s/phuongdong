<?php 
return [
    'next' => '›',
    'prev' => '‹',
    // 'first' => '«',
    'first' => 'Đầu',
    // 'last' => '»',
    'last' => 'Cuối',
];
?>