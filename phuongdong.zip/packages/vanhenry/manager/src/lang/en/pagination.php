<?php 
return [
    'next' => '›',
    'prev' => '‹',
    'first' => 'First',
    'last' => 'Last',
];
?>