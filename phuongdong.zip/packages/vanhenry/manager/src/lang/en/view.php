<?php 
return [
    'hello' => 'Hello'
];

?>