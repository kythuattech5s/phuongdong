<td data-title="{{$show->note}}">

<p>{{FCHelper::ep($dataItem,$show->name)}}</p>

</td>