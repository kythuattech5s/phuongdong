<td data-title="{{$show->note}}">

<img src="{{FCHelper::ep($dataItem,$show->name)}}" style="max-width: 70px;max-height: 70px;margin: 2px auto;" class="img-responsive">

</td>