@extends('vh::master')
@section('content')
<div class="header-top aclr">
  <div class="alert alert-success">
    thành công
  </div>  
  @include('vh::static.footer')
</div>
<style type="text/css">
  h3.title-import{
    text-align: center;
    font-size: 20px;
    text-transform: uppercase;
  }
  h3.title-import a{
    font-weight: bold;
  }
</style>
@stop