<div class="data-select" data-select="static">
	<input type="hidden">
	<button type="button" class="btn btn-default">Chọn trang tĩnh</button>
	<div class="select-search">
	  <input type="text" placeholder="{{trans('db::SEARCH')}}">
	  <ul>
	    <li data-value="sp1">Trang tĩnh 1</li>
	    <li data-value="sp2">Trang tĩnh 2</li>
	    <li data-value="sp3">Trang tĩnh 3</li>
	    <li data-value="sp4">Trang tĩnh 4</li>
	    <li data-value="sp5">Trang tĩnh 5</li>
	  </ul>
	  <div class="select-pagination">
	    <a href="#" title="" class="sp-prev"><i class="fa fa-angle-left"></i></a>
	    <a href="#" title="" class="sp-next"><i class="fa fa-angle-right"></i></a>
	  </div>
	</div>
</div>