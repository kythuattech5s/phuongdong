<div class="data-select" data-select="{{$ksm}}">
  <input type="text" class="input-tag-link">
</div>