@extends('vh::master')
@section('content')
@include('vh::static.headertop')
<div id="maincontent">
  	
</div>
@include('vh::static.footer')
@stop