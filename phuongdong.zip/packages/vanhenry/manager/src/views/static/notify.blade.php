<!-- <div data-option="notify" class="notification aclr">



            <i class="fa fa-exclamation-triangle warning" aria-hidden="true"></i>



            <p style="text-transform: uppercase;    padding: 5px 0px;"> Tech 5S thông báo,</p>



            <p>Chúng tôi sẽ tiến hành bảo trì hệ thống quản trị từ 12h -> 1H đêm nay (0H 12/05) để tối ưu tốc độ.</p>



            <p>Các chức năng khác vẫn hoạt động bình thường. Xin lỗi quý khách</p>



            </p>



            <i class="fa fa-times-circle close"  aria-hidden="true"></i>



          </div>



          <div data-option="nghile" class="notification aclr">



            <i class="fa fa-exclamation-triangle warning" aria-hidden="true"></i>



            <p style="text-transform: uppercase;    padding: 5px 0px;"> Tech 5S thông báo,</p>



            <p>Chúng tôi sẽ tiến hành bảo trì hệ thống quản trị từ 12h -> 1H đêm nay (0H 12/05) để tối ưu tốc độ.</p>



            <p>Các chức năng khác vẫn hoạt động bình thường. Xin lỗi quý khách</p>



            </p>



            <i class="fa fa-times-circle close"  aria-hidden="true"></i>



          </div> -->



