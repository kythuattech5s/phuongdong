<div class="copyright tac">
    <p>TECH 5S CMS 8.x</p>
</div>