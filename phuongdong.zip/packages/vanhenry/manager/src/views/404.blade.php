
<div id="maincontent" style="text-align: center;height: 85vh">
  	<img src="{{asset('public/images/404.png')}}" alt="Không tìm thấy">
</div>
