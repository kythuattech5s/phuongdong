<html>
	<head>
		<meta name="viewport" content="width=device-width">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<base href="{{asset('/')}}">
	</head>
	<body>
		<h1 style="text-align:center"><?php echo @$error; ?></h1>
	</body>
</html>