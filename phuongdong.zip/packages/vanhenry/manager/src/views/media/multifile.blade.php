@foreach($infos as $file)
	@include("vh::media.file")
@endforeach