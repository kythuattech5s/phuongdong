<section class="container-fluid">
	<p class="title-top-alls text-30 opensan-semi mb-3">Báo cáo doanh thu bán hàng</p>
</section>