@extends('vh::master')
@section('content')
@include('vh::static.headertop')
<div id="maincontent" style="text-align: center;height: 85vh">
  	Không có quyền truy cập
</div>
@stop