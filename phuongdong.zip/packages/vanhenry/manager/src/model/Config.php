<?php

namespace vanhenry\manager\model;

use Illuminate\Database\Eloquent\Model;

class Config extends Model
{
	public $incrementing = false;
}
