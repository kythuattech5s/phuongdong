<?php

namespace vanhenry\manager\model;

use Illuminate\Database\Eloquent\Model;

class VDetailTable extends Model
{
    //
}
