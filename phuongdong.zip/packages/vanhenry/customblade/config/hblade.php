<?php 

return array(
	"time_cache" =>24*60,

);

 ?>